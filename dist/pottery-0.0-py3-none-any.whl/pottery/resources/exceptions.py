class PotteryException(Exception):
    pass