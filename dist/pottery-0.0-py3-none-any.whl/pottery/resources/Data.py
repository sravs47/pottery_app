
products_list =[{
    'id':1,
    'name':'Mug 1',
    'title':'Mug',
    'description':'Mug',
    'weight':10,
    'dimentions':'1x1x2',
    'price':10,
    'image':'1.jpg'

},{
    'id':2,
    'name':'Mug 2',
    'title':'Mug',
    'description':'Mug',
    'weight':20,
    'dimentions':'1x1x3',
    'price':20,
    'image':'2.jpg'

},{
    'id':3,
    'name':'Mug 3',
    'title':'Mug',
    'description':'Mug',
    'weight':30,
    'dimentions':'1x1x3',
    'price':30,
    'image':'3.jpg'

},{
    'id':4,
    'name':'Mug 4',
    'title':'Mug',
    'description':'Mug',
    'weight':40,
    'dimentions':'1x1x4',
    'price':40,
    'image':'4.jpg'

},{
    'id':5,
    'name':'Mug 5',
    'title':'Mug',
    'description':'Mug',
    'weight':50,
    'dimentions':'1x1x5',
    'price':50,
    'image':'5.jpg'

}]
